<div class="se-iii py-90" id="display_package">
    <div class="container">
      <!-- se-head -->
      <div class="se-head">
        <h3 class="se-title-1">What about our plans</h3>
        <h4 class="se-title-2">Get More Power With Our Web & Email Hosting Products</h4>
      </div>
      <!-- plans -->
      <div class="plans mb-xl-4 mb-2">
        <!-- row -->
        <div class="row mx-xl-0">
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- plan-head -->
              <div class="plan-head">
                <!-- plan-name -->
                <h3 class="plan-name">Standard Jet</h3>
                <!-- plan-para -->
                <p class="plan-para">When you need just one site to get started</p>
              </div>
              <!-- plan-price -->
              <div class="plan-price">
                <!-- price -->
                <h4 class="price">$6.99</h4>
                <!-- price-comment -->
                <p class="price-comment">Renew $6.99 - 12/mo term</p>
              </div>
              <!-- actions -->
              <div class="actions">
                <a href="https://shop.hellencp.com/domain-required?p=package:134702&t=12" target="blank" class="btn btn-fill-primary btn-sm shadow-off w-100">Get Started</a>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Top Features</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">1 Website <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">20 GB SSD Storage <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unlimited Bandwidth <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">20 x 5GB Mailboxes <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                </ul>
              </div>
             
              <!-- group -->
              <div class="group">
                
                <h4 class="title-4">Also Includes</h4>
                
                <ul class="list list-unstyled">
                <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Free Wildcard SSL Certificates<span class="float-box" data-text="One free with purchase of a new 12-, 24- or 36-month plan. Plus ICANN fee of 2.84 USD per domain name per year. You must add the domain name into your cart before purchase, and you must select a domain term length equal to or less than the term length of your plan to qualify for the free domain offer. If you purchase a domain name for a term longer than the term of the plan, you will be charged for the additional registration term at the then-current rate. Cannot be used in conjunction with any other offer, sale, discount or promotion. Free domain offer applies only to the initial purchase term. After the initial purchase term, domains purchased through this offer will renew at the then-current renewal price."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Malware Scanning</li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">DDoS Protection</li>                 
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Website Builder</li>                 
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan popular-plan">
              <!-- plan-head -->
              <div class="plan-head">
                <!-- plan-name -->
                <h3 class="plan-name">Premium Jet </h3>
                <!-- plan-para -->
                <p class="plan-para">For those running multiple sites.</p>
              </div>
              <!-- plan-price -->
              <div class="plan-price">
                <!-- price -->
                <h4 class="price">$15.99</h4>
                <!-- price-comment -->
                <p class="price-comment">Renew $15.99 - 12/mo term</p>
              </div>
              <!-- actions -->
              <div class="actions">
                <a href="https://shop.hellencp.com/domain-required?p=package:134692&t=12" target="blank" class="btn btn-fill-primary btn-sm shadow-off w-100">Get Started</a>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Top Features</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unlimited Website <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unlimited SSD Storage <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unlimited Bandwidth <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unlimited x 10GB Mailboxes <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                </ul>
              </div>
            
              <!-- group -->
              <div class="group">
                
                <h4 class="title-4">Also Includes</h4>
                
                <ul class="list list-unstyled">
                <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Free Wildcard SSL Certificates<span class="float-box" data-text="One free with purchase of a new 12-, 24- or 36-month plan. Plus ICANN fee of 2.84 USD per domain name per year. You must add the domain name into your cart before purchase, and you must select a domain term length equal to or less than the term length of your plan to qualify for the free domain offer. If you purchase a domain name for a term longer than the term of the plan, you will be charged for the additional registration term at the then-current rate. Cannot be used in conjunction with any other offer, sale, discount or promotion. Free domain offer applies only to the initial purchase term. After the initial purchase term, domains purchased through this offer will renew at the then-current renewal price."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Malware Scanning</li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">DDoS Protection</li>                 
                </ul>
              </div>

            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- plan-head -->
              <div class="plan-head">
                <!-- plan-name -->
                <h3 class="plan-name">Email Essential</h3>
                <!-- plan-para -->
                <p class="plan-para">With added privacy and security features.</p>
              </div>
              <!-- plan-price -->
              <div class="plan-price">
                <!-- price -->
                <h4 class="price">$5.99</h4>
                <!-- price-comment -->
                <p class="price-comment">Renew $5.99 - 12/mo term</p>
              </div>
              <!-- actions -->
              <div class="actions">
                <a href="https://shop.hellencp.com/domain-required?p=package:135308&t=12" target="blank" class="btn btn-fill-primary btn-sm shadow-off w-100">Get Started</a>
              </div>
              <!-- group -->
              <div class="group">
                
                <h4 class="title-4">Top Features</h4>
                
                <ul class="list list-unstyled">
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">1 x Domain <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">0GB SSD Web storage <span class="float-box" data-text="We don't limit the amount of storage and bandwidth your site can use as long as it complies with our Hosting Agreement. Should your website bandwidth or storage usage present a risk to the stability, performance or uptime of our servers, we will notify you via email and you may be required to upgrade, or we may restrict the resources your website is using. It’s very rare that a website violates our Hosting Agreement and is typically only seen in sites that use hosting for file sharing or storage."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Unlimited Bandwidth<span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">20 x 7GB Mailboxes<span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                </ul>
              </div>

              
              <div class="group">
                
                <h4 class="title-4">Also Includes</h4>
                
                <ul class="list list-unstyled">
                <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Free Wildcard SSL Certificates<span class="float-box" data-text="One free with purchase of a new 12-, 24- or 36-month plan. Plus ICANN fee of 2.84 USD per domain name per year. You must add the domain name into your cart before purchase, and you must select a domain term length equal to or less than the term length of your plan to qualify for the free domain offer. If you purchase a domain name for a term longer than the term of the plan, you will be charged for the additional registration term at the then-current rate. Cannot be used in conjunction with any other offer, sale, discount or promotion. Free domain offer applies only to the initial purchase term. After the initial purchase term, domains purchased through this offer will renew at the then-current renewal price."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Malware Scanning</li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">DDoS Protection</li>

                </ul>
              </div>

            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- plan-head -->
              <div class="plan-head">
                <!-- plan-name -->
                <h3 class="plan-name">Email Premium</h3>
                <!-- plan-para -->
                <p class="plan-para">Get more power with optimized web resources.</p>
              </div>
              <!-- plan-price -->
              <div class="plan-price">
                <!-- price -->
                <h4 class="price">$14.99</h4>
                <!-- price-comment -->
                <p class="price-comment">Renew $14.99 - 12/mo term</p>
              </div>
              <!-- actions -->
              <div class="actions">
                <a href="https://shop.hellencp.com/domain-required?p=package:135320&t=12" target="blank" class="btn btn-fill-primary btn-sm shadow-off w-100">Get Started</a>
              </div>
              <!-- group -->
              <div class="group">
                
                <h4 class="title-4">Top Features</h4>
                
                <ul class="list list-unstyled">
                <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">6 x Domain <span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">10MB SSD Web storage <span class="float-box" data-text="We don't limit the amount of storage and bandwidth your site can use as long as it complies with our Hosting Agreement. Should your website bandwidth or storage usage present a risk to the stability, performance or uptime of our servers, we will notify you via email and you may be required to upgrade, or we may restrict the resources your website is using. It’s very rare that a website violates our Hosting Agreement and is typically only seen in sites that use hosting for file sharing or storage."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Unlimited Bandwidth<span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Unlimited x 10GB Mailboxes<span class="float-box" data-text="An economical, 25 GB plan with matching domain and email (with terms of 12/mo. or longer)."></span></li>
                </ul>
              </div>

              
              <div class="group">
                
                <h4 class="title-4">Also Includes</h4>
                
                <ul class="list list-unstyled">
                <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Free Wildcard SSL Certificates<span class="float-box" data-text="One free with purchase of a new 12-, 24- or 36-month plan. Plus ICANN fee of 2.84 USD per domain name per year. You must add the domain name into your cart before purchase, and you must select a domain term length equal to or less than the term length of your plan to qualify for the free domain offer. If you purchase a domain name for a term longer than the term of the plan, you will be charged for the additional registration term at the then-current rate. Cannot be used in conjunction with any other offer, sale, discount or promotion. Free domain offer applies only to the initial purchase term. After the initial purchase term, domains purchased through this offer will renew at the then-current renewal price."></span></li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">Malware Scanning</li>
                  <li><img class="lazy img-fluid" alt="Icon" src="assets/images/pages/shared-hosting/check-circle.svg" style="">DDoS Protection</li>                 
                </ul>
              </div>

            </div>
          </div>
        </div>
      </div>
      <!-- se-footer -->
      <div class="se-footer d-flex align-items-center justify-content-center flex-wrap">
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Backups monthly</span>
        </div>
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Free & simple migrations</span>
        </div>
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Staging enviroments, ande more.</span>
        </div>
      </div>
    </div>
  </div>