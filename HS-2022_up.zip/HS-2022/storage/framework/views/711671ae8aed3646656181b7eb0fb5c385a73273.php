
<?php $__env->startSection('title','Email Premium'); ?>
<?php $__env->startSection('contents'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.MasterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HS-2022\resources\views/hosting_packages/email_premium.blade.php ENDPATH**/ ?>